module.exports = {
    parserOptions: {
        project: ["./tsconfig.json"],
    },
    plugins: ["@hboictcloud"],
    extends: ["plugin:@hboictcloud/base"]
};
