# Ontwikkeldoel Blok 2

## Tejash 
Ik wil meer handigheid krijgen in het werken met TypeScript. Ik heb niet echt kennis er mee. Mijn doel is om het onder de knie te krijgen, door online te onderzoeken hoe het werkt en ook TypeScript codes te schrijven. Verder wil ik meer aandacht besteden aan mijn opleiding. Hiermee bedoel ik dat ik minstens 1 of 2 dagen thuis werk in de week en probeer om elke schooldag te komen naar de les. Ik kon vorig blok soms niet komen, omdat ik regelmatig ziek was, dit wil ik dus veranderen.

## Anwar
Ik vind dat ik heel goed ben geworden met Javascript vorige project. Mijn  doel nu voor deze blok is om al deze skills over te zetten naar Typescript. 