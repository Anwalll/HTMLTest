# Warm up:
Tejash en ik hebben gekozen voor de warm-up: Team in 1 word:
Ask everyone to write one word that describes the team.
Everyone put these words up on a wall or whiteboard and tells a
few words about what they mean.

Ik schreef: Ontwikkellen. Ik vind dat we goed op weg zijn zowel als team maar ook individuel en nog een hoop te leren hebben.
Tejash schreef: Gecoördineerd . We geven duidelijk rollen over wie wat doet en we volgen deze ook.
# Retro-kit Spel
#### Wind = Onze samenwerking
#### Anchor = Soms spelen we wat met de CSS
#### Risk = Geen 
#### Island = Onze creativiteit
#### Sun = De werk die we tot nu toe hebben gemaakt
